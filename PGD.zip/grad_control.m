function d = grad_control(d,flag)
if flag
    max_grad = 0.1;
    nn = max_grad;

    nd = norm(d,inf);
    if nd > max_grad
        d = (d/nd).*nn;
    end
end
end