function [h,DA] = objective_Newton_new(delta,w,S,A,lambda)
    Delta = w2L(delta);
    DA = Delta*A;
    t = trace( Delta*S) - trace(DA) + 0.5*trace((DA)'*DA);
    r = MCP(w + delta,lambda);
    h = t + r;
%     
%     disp('*****')
%     h
%     t
%     r
%     disp('*****')
end
