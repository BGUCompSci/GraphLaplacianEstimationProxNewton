function g = grad_by_delta_new(delta,w,S,A,lambda,p,DA)
    %Delta = w2L(delta);
    if p
    	dM = diag(A);
    	P = (dM + dM' - 2*A).^2;
    	z = gMCP(delta + w,lambda);
    	g = -(Lstar(S - A + A'*DA)+z)./L2w(P);
    else
         g = Lstar(S - A + A'*DA) + gMCP(delta + w,lambda);
 end