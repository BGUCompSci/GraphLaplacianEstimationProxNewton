function [L,error,fs,T] = NGL_NewtonMCP_CG_debug4(Lt,S,lambda,nDp) % with Palomar's porjection
tic
T(1) = 0;
wt = L2w(Lt);
n = size(S,1);         
tr = 10^(-5);          %thresholding
err = 10^(-4);  %-4        % stop if: ||f(w)-f(wnew)|| < err
maxIter = 100;         % number of newton iterations
warmStart = 1;
ploting_flag = 1;
%lineseaech main loop cont's:
maxIter_line = 7;   % number of iterations for linesearch
eta = .7;
beta = 0.3;
k = 0;
normLt = norm(Lt,'fro');
f = @(w) objective_f(w,S,lambda);


if nDp > 1
	w0 = w_init_data(S,lambda);
else
	w0 = w_init0(S,lambda);
end 

[obj(k+1),L]  = f(w0); %f(w0)
nnzs(k+1) = 2*nnz(w0) + n;
error(k+1) = norm(Lt-L,'fro')/normLt;
fs(k+1) = F_score(w0,wt);
k = k+1;


if warmStart %w0
	w = NGL_GD_warmStart(S,0,w0);
   % w = NGL_GD_warmStart(S,0.2,w);
	eta = 1;
else
    w = w0;
end

[obj(k+1),L]  = f(w); %f(w0)
nnzs(k+1) = 2*nnz(w) + n;
error(k+1) = norm(Lt-L,'fro')/normLt;
fs(k+1) = F_score(w,wt);
T(k+1) = toc;
%============================= main loop ==================================
while k == 0 || k < maxIter 
    d = newton4(w,L,S,lambda); %find newton direction
    wold = w;
    [w,obj(k+2),L] = update_w(w,d,f,obj(k+1),maxIter_line,eta ,beta,tr);
    T(k+2) = toc;
    k = k + 1;    
    nnzs(k+1) = 2*nnz(w) + n;
    error(k+1) = norm(Lt-L,'fro')/normLt;
    fs(k+1) = F_score(w,wt);
    stop_cond = norm(w-wold)/norm(wold) < err; %&& nnzs(k+1) >= nnzs(k);
    if stop_cond
        break
    end
    eta = min(1,eta + 0.02);
end
if ploting_flag
    ploting(k,error,obj,nnzs,T);
end
end
