function z = gMCPForGivenGama(w,lambda,gama)
%output z (size of w and w>=0)
S =  w <= gama*lambda;
z = (lambda - w/gama).*S;
end