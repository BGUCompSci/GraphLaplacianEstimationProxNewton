function delta = newton4(w,L,S,lambda)

% CG with pre-cond - QN
activeSet = 1;
M = 1;
if activeSet == 1
    g0 = grad_by_w_of_f(w,S,lambda,L,0);
    M = w > 0;
    M = M + ( g0 < -lambda);
end
maxIter_Newton = 15;
maxIter_linesearch = 5;
n = size(S,1);
eta = 1;
beta = 0.1;
e_D = 10^(-10);
J = 1/n;
g_control = 0;
err = 0.01;
precond_newton = 1; 


A = inv(L + J + e_D*eye(n));

h = @(delta) objective_Newton_new(delta,w,S,A,lambda);
grad = @(delta,DA) grad_by_delta_new(delta,w,S,A,lambda,precond_newton,DA);

delta = zeros(size(w)); %delta0
[hold,DA] = h(delta);
for t = 1:maxIter_Newton
	delta_old  =delta;
	if t == 1 %calcolate d
        g = grad_control(grad(w,DA),g_control).*M;
    	d = -g;
    else
        g_old = g;
        g = grad_control(grad(w,DA),g_control).*M;
        d_old = d;
        norm_dd_old = norm(d_old)^2;
        y = g - g_old;
        p = 1 + max(0,-dot(d_old,y)/norm_dd_old);
        a = y + p*d_old;
        dot_d_old_a = dot(d_old,a);
        eta_k = 1 - dot(g,d_old)/dot_d_old_a;
        beta_PDY = (norm(g)^2)/dot_d_old_a;
        d = -eta_k*g + beta_PDY*d_old;
    end
        
    for p = 1:maxIter_linesearch
        z = max(delta + eta*d,-w);
        [hnew,DA] = h(z);
        lines_cond =  hnew < hold ;      
        if lines_cond
            delta = z;
            break
        end
        eta = eta*beta;
    end
    if p == maxIter_linesearch  || norm(delta - delta_old)/norm(delta) < err
        break
    end
    hold = hnew;
end
%t
end

